***LEGISLATIVE DATASET***
import delimited Data\AVPMainData.csv, clear

*Figure 3.6*
melogit votebin partybin sexbin blackracebin pcgovwork blackpc mrp_mean privschenrolmentpc righttoworkstateattimeofpassage pcunionstatelev stateedexppc yearprogramcreated taxexpdesign repsponserbin malesponsorbin ib4.targetcat || statefipscode: || geoid:
margins, at (blackpc=(0(9.355226)93.55226))
marginsplot, recast(line) plotopts(lcolor(black)) recastci(rarea) ciopts(fcolor(gs11) lcolor(gs11) lwidth(none)) ytitle(Likelihood of voting in favor of a voucher) ylabel(, angle(horizontal) nogrid) xtitle(Percentage of African Americans in district population) title("") plotregion(lcolor(none))

*Figure 5.3*
melogit votebin partybin sexbin blackracebin pcgovwork blackpc mrp_mean privschenrolmentpc righttoworkstateattimeofpassage pcunionstatelev stateedexppc yearprogramcreated taxexpdesign repsponserbin malesponsorbin ib4.targetcat || statefipscode: || geoid:
margins, at (pcunionstatelev=(2(2)18)) 
marginsplot, recast(line) plotopts(lcolor(black)) recastci(rarea) ciopts(fcolor(gs11) lcolor(gs11) lwidth(none)) ytitle(Likelihood of voting in favor of a voucher) ylabel(, angle(horizontal) nogrid) xtitle(Unionized workers as a percentage of the state workforce) title("") plotregion(lcolor(none))

*Figure 5.4*
melogit votebin partybin sexbin blackracebin pcgovwork blackpc mrp_mean privschenrolmentpc righttoworkstateattimeofpassage pcunionstatelev stateedexppc yearprogramcreated taxexpdesign repsponserbin malesponsorbin ib4.targetcat || statefipscode: || geoid:
margins, at (pcgovwork=(.034507(.04848558).5193628))
marginsplot, recast(line) plotopts(lcolor(black)) recastci(rarea) ciopts(fcolor(gs11) lcolor(gs11) lwidth(none)) ytitle(Likelihood of voting in favor of a voucher) ylabel(, angle(horizontal) nogrid) xtitle(Government workers as a percentage of all district workers) title("") plotregion(lcolor(none))

*Figure 5.5*
melogit votebin partybin sexbin blackracebin pcgovwork blackpc mrp_mean privschenrolmentpc righttoworkstateattimeofpassage pcunionstatelev stateedexppc yearprogramcreated taxexpdesign repsponserbin malesponsorbin ib4.targetcat || statefipscode: || geoid:
margins, at (righttoworkstateattimeofpassage=(0 1))
marginsplot, recast(scatter) plotopts(color(black)) recastci(rspike) ciopts(color(black)) ///
xtitle("") xlab(-0.5 " " 0 "Not right to work state" 1 "Right to work state" 1.5 " ", notick) ///
ytitle(Likelihood of voting in favor of a voucher) ylabel(, angle(horizontal) nogrid)  ///
title("") plotregion(lcolor(none))

*Figure 6.1*
melogit votebin partybin sexbin blackracebin pcgovwork blackpc mrp_mean privschenrolmentpc righttoworkstateattimeofpassage pcunionstatelev stateedexppc yearprogramcreated taxexpdesign repsponserbin malesponsorbin ib4.targetcat || statefipscode: || geoid:
margins, at (partybin=(0 1))
marginsplot, recast(scatter) plotopts(color(black)) recastci(rspike) ciopts(color(black)) ///
xtitle("") xlab(-0.5 " " 0 "Democrat" 1 "Republican" 1.5 " ", notick) ///
ytitle(Likelihood of voting in favor of a voucher) ylabel(, angle(horizontal) nogrid)  ///
title("") plotregion(lcolor(none))

*Figure 6.2*
melogit votebin partybin sexbin blackracebin pcgovwork blackpc mrp_mean privschenrolmentpc righttoworkstateattimeofpassage pcunionstatelev stateedexppc yearprogramcreated taxexpdesign repsponserbin malesponsorbin ib4.targetcat || statefipscode: || geoid:
margins, at (mrp_mean=(-1.073578(.19134797).8399017))
marginsplot, recast(line) plotopts(lcolor(black)) recastci(rarea) ciopts(fcolor(gs11) lcolor(gs11) lwidth(none)) ytitle(Likelihood of voting in favor of a voucher) ylabel(, angle(horizontal) nogrid) xtitle(District ideology) title("") plotregion(lcolor(none))

*Figure 7.2*
melogit votebin partybin sexbin blackracebin pcgovwork blackpc mrp_mean privschenrolmentpc righttoworkstateattimeofpassage pcunionstatelev stateedexppc yearprogramcreated taxexpdesign repsponserbin malesponsorbin ib4.targetcat || statefipscode: || geoid:
margins, at (targetcat=(1 2 3 4))
marginsplot, recast(scatter) plotopts(color(black)) recastci(rspike) ciopts(color(black))

***JUDICIAL DATASET***

*Figure 6.4*
logit indivdecbin partybin sexbin racebin whenchallenged nap programtypbin ib3.region,cluster (courtnum)
margins, at(partybin=(0 1))
marginsplot, recast(scatter) plotopts(color(black)) recastci(rspike) ciopts(color(black)) ///
xtitle("") xlab(-0.5 " " 0 "Democratic" 1 "Republican" 1.5 " ", notick) ///
ytitle(Likelihood of voting in favor of a voucher) ylabel(, angle(horizontal) nogrid)  ///
title("") plotregion(lcolor(none))

*Figure 6.5*
logit indivdecbin partybin sexbin racebin whenchallenged nap programtypbin ib3.region,cluster (courtnum)
margins, at (programtypbin=(0 1))
marginsplot, recast(scatter) plotopts(color(black)) recastci(rspike) ciopts(color(black)) ///
xtitle("") xlab(-0.5 " " 0 "Weakly attenuated" 1 "Deeply attenuated" 1.5 " ", notick) ///
ytitle(Likelihood of voting in favor of a voucher) ylabel(, angle(horizontal) nogrid)  ///
title("") plotregion(lcolor(none))

*Figure 7.3*
logit indivdecbin partybin sexbin racebin whenchallenged nap programtypbin ib3.region,cluster (courtnum)
margins, at (whenchallenged=(1955(5)2016))
marginsplot, recast(line) plotopts(lcolor(black)) recastci(rarea) ciopts(fcolor(gs11) lcolor(gs11) lwidth(none)) ytitle(Likelihood of voting in favor of a voucher) ylabel(, angle(horizontal) nogrid) xtitle(Year of challenge) title("") plotregion(lcolor(none))
