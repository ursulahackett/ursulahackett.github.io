setwd("C:/Users/udtp002/Documents/R")

### Load libraries
library(ggplot2)

### Load data
dat <- read.csv("choroData.csv")

### Set up the bare plot
p <- ggplot(data = dat,
            aes(x = long, y = lat, group = group,
                fill = factor(Segregation.grant)))

### Add on the state boundaries
p <- p + 
  geom_polygon()

### Paint state borders in white
p <- p + 
  geom_path(colour = "white")

#Attach black white grey colors to specific categories
cols <- c("No" = "grey76", "Yes" = "#000000", "Privately funded" = "grey47")
p <- p + scale_fill_manual(values = cols)

##Get rid of legend
p <- p +
  theme(legend.position = "none")


  
### Set the background to white
p <- p +
  theme(panel.background = element_rect(fill = "white"))

### Remove axes
p <- p +
  theme(axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.text.x = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks = element_blank())

#Annotate map with year of grant passage
#Louisiana
p <- p + annotate("text", x = 710000, y = -1400000, label = "1958", color = "white")
#North Carolina
p <- p + annotate("text", x = 1805351, y = -800934, label = "1956", color = "white")
#Georgia
p <- p + annotate("text", x = 1569090, y = -1219625, label = "1953", color = "white")
#Alabama
p <- p + annotate("text", x = 1255807, y = -1318907, label = "1955", color = "white")
#Virginia
p <- p + annotate("text", x = 1854526, y = -572524, label = "1956", color = "white")
#South Carolina
p <- p + annotate("text", x = 1729611, y = -1060878, label = "1963", color = "white")
#Mississippi
p <- p + annotate("text", x = 950316, y = -1319344, label = "1964", color = "white")

p
