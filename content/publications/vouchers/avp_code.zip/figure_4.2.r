setwd("C:/Users/udtp002/Documents/R")

### Load libraries
library(ggplot2)

### Load data
dat <- read.csv("choroData.csv")

### Set up the bare plot
p <- ggplot(data = dat,
            aes(x = long, y = lat, group = group,
                fill = factor(NAP.score)))

### Add on the state boundaries
p <- p + 
  geom_polygon()

### Paint state borders in white
p <- p + 
  geom_path(colour = "white")

#Attach black white grey colors to specific categories
cols <- c("0" = "grey95", "2" = "grey80", "3" = "grey70", "4" = "grey60", "5" = "grey50", "6" = "grey40", "7" = "grey30", "8" = "grey20", "9" = "grey10")
p <- p + scale_fill_manual(values = cols)

##Get rid of legend
p <- p +
  theme(legend.position = "none")

### Set the background to white
p <- p +
  theme(panel.background = element_rect(fill = "white"))

### Remove axes
p <- p +
  theme(axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.text.x = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks = element_blank())

p
